package com.example.random;

import androidx.appcompat.app.AppCompatActivity;

import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import java.util.Timer;
import java.util.Arrays;


import com.asus.robotframework.API.MotionControl;
import com.asus.robotframework.API.RobotAPI;
import com.asus.robotframework.API.RobotFace;


import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private RobotAPI mRobotAPI;
    private CountDownTimer mCountDownTimer;
    int name=0;
    int counter=10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Thread myThread = new Thread(new MyServerThread());
        myThread.start();

        mRobotAPI  = new RobotAPI(this);


        mCountDownTimer  = new CountDownTimer(8000,1000) {

            public void onTick(long millisUntilFinished) {

            }

            public void onFinish() {
                mRobotAPI.robot.setExpression(RobotFace.DEFAULT);
            }

        };
    }

    public static int generateRandomIntIntRange(int min, int max) {

        Random r = new Random();

        return r.nextInt((max - min) + 1) + min;

    }

   /* public class NDigitNumNonRep {

        /**
         * 获取count个随机数
         *
         * @param count 随机数个数
         * @return
         */
       /* public String game(int count) {
            StringBuffer sb = new StringBuffer();
            String str = "0123456789";
            Random r = new Random();
            for (int i = 0; i < count; i++) {
                int num = r.nextInt(str.length());
                sb.append(str.charAt(num));
                str = str.replace((str.charAt(num) + ""), "");
            }
            return sb.toString();

        }
    }*/

    class MyServerThread implements Runnable {
        Socket s;
        ServerSocket ss;
        BufferedReader bufferedReader;
        //byte[] bytes;
        Handler h = new Handler();
        String str;
        String rNum;

        @Override
        public void run() {
            try {
                System.out.println("Server running...");
                ss = new ServerSocket(8000, 0, InetAddress.getByName("10.41.20.117"));
                System.out.println(ss.getInetAddress());
                System.out.println(ss.getLocalPort());
                while (true) {
                    s = ss.accept();
                    System.out.println("Got in");
                    bufferedReader = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    str = bufferedReader.readLine();
                    /*System.out.println(str);*/
                    s.close();

                    h.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
                            /*if (str.equals("I am walking")) {
                                System.out.println("Go forward");
                                mRobotAPI.motion.remoteControlBody(MotionControl.Direction.Body.FORWARD);

                            }
                            if (str.equals("I am happy")) {
                                System.out.println("Zenbo Happy");
                                mRobotAPI.robot.setExpression(RobotFace.HAPPY);
                            }
                            if (str.equals("Joke")) {
                                String story1, story2, story3, story4, story5;

                                story1 = "Of course I should clean my windows. But privacy is important too";
                                story2 = "Why are eggs not very much into jokes? Because they could crack up. ";
                                story3 = "Talk is cheap, yeah? Have you ever talked to a lawyer?!";
                                story4 = "Do I lose when the police officer says papers and I say scissors?";
                                story5 = " The mathematician who invented zero? Thanks a lot for nothing.";

                                switch (generateRandomIntIntRange(1, 5)) {
                                    case 1:
                                        mRobotAPI.robot.speak(story1);
                                        mRobotAPI.robot.setExpression(RobotFace.HAPPY);
                                        break;
                                    case 2:
                                        mRobotAPI.robot.speak(story2);
                                        mRobotAPI.robot.setExpression(RobotFace.HAPPY);
                                        break;
                                    case 3:
                                        mRobotAPI.robot.speak(story3);
                                        mRobotAPI.robot.setExpression(RobotFace.HAPPY);
                                        break;
                                    case 4:
                                        mRobotAPI.robot.speak(story4);
                                        mRobotAPI.robot.setExpression(RobotFace.HAPPY);
                                        break;
                                    case 5:
                                        mRobotAPI.robot.speak(story5);
                                        mRobotAPI.robot.setExpression(RobotFace.HAPPY);
                                        break;
                                }
                                mCountDownTimer.start();
                            }*/
                            if (str.equals("Start")) {
                                //generate a 4 digits number without repitition
                                Random ran=new Random();
                                int r=0;
                                m1:while(true){
                                    int n=ran.nextInt(10000);
                                    r=n;
                                    int[] bs=new int[4];
                                    for(int i=0;i<bs.length;i++){
                                        bs[i]=n%10;
                                        n/=10;
                                    }
                                    Arrays.sort(bs);
                                    for(int i=1;i<bs.length;i++){
                                        if(bs[i-1]==bs[i]){
                                            continue m1;
                                        }
                                    }
                                    break;
                                }
                                rNum=String.valueOf(r);

                                System.out.println("The game is ready");
                                /*mRobotAPI.robot.setExpression(RobotFace.HAPPY);*/
                                mRobotAPI.robot.speak("Okay the game is ready, please guess a four digits number");
                            }
                            if (str.length()>13) {
                                String strNotice=str.substring(0,13);
                                if (strNotice.equals("My number is ")) {
                                    String strNum=str.substring(13,17);
                                    counter -=1;
                                    if (strNum.equals(rNum)){
                                        mRobotAPI.robot.setExpression(RobotFace.HAPPY);
                                        System.out.println("You are right! The number is "+rNum);
                                        mRobotAPI.robot.speak("Bingo");
                                        counter=10;
                                    }
                                    else if (counter==0){
                                        System.out.println("Game Over"+rNum);
                                        mRobotAPI.robot.speak("Sorry, chance runs out. You lose!");
                                        counter=10;

                                    }
                                    else {
                                        int RightDigit=0;
                                        int RightNum=0;

                                        for(int i=0;i<strNum.length();i++) {
                                            if(rNum.substring(i,i+1).equals(strNum.substring(i,i+1)))
                                                RightDigit +=1;
                                            else if(rNum.contains(strNum.substring(i,i+1)))
                                                RightNum +=1;

                                        }
                                        System.out.println("Try again, you have "+counter+" more chance");
                                        mRobotAPI.robot.speak("Your answer has "+RightDigit+" right digit and "+RightNum+" right num in addition");

                                    }
                                }
                                /*System.out.println("Zenbo Happy");
                                name=5;

                                int g=Integer.parseInt(str);
                                mRobotAPI.robot.setExpression(RobotFace.HAPPY);*/
                            }

                            /*   str= "my number is 4"

                            if the first  eight characters of my str are "my number"

                            T

                            if the last character of my str is = to name
                            int g=Integer.parseInt(str);
                       */

                            /*else {
                                mRobotAPI.robot.speak(str);

                            }*/

                        }
                    });
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }




}
